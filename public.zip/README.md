<h2>Time to tour website </h2>
<li>This is a totally dynamic website</li>
<li>Anyone can add any kind of services after registration</li>
<li>Any registered user can see and add comment in any kind of service details page (after login)</li>
<li>Registered authorized user also can edit or delete the commented comment (after login)</li>
<li>Registered user can see his sercies that he/she added in this website (after login)</li>
<li>Registered user can see his all activity in my review page (after login)</li>
<li>all the data will be sorted decending order so that user can see the recent one in the first.</li>
<li>Add a service, My reviews, My services all are jwt verified route</li>
